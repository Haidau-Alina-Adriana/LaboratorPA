create PROCEDURE display_result (p_title IN general_entertainment.title%TYPE) AS
    p_result general_entertainment.date_of_premier%TYPE;
BEGIN
    search_date(p_title, p_result);
    DBMS_OUTPUT.PUT_LINE('Your show appeared on ' || p_result);
END;
/

